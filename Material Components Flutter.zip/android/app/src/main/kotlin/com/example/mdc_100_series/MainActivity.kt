package com.example.mdc_100_series

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
